
$(document).ready(function() {
	//alert('am aaaaaaaaaaaaaaaaaa');

	$('#js-date').datepicker();
	
    // date 

	$('#btn-get-info').click(function () {
  		 
		if ( $('#fname').val().match('^[a-zA-Z]{3,16}$') ) {
		        //alert( "Valid name" );
		    }
		     else {
		        // alert("Please Enter Your First Name name");
		        $('#errormsg').html('Please Enter Your First Name name');
		        return false;
		    }

		    if ( $('#lname').val().match('^[a-zA-Z]{3,16}$') ) {
		        //alert( "Valid last name name" );
		    }
		    else {
		        // alert("Please Enter Your Last Name name");
		        $('#errormsg').html('<p>Please Enter Your Last Name name</p>');
		        return false
		    }

		    if ( $('#contactnumber').val().match('[0-9]') ) {
		        //alert( "Valid last name name" );
		    }
		    else {
		        // alert("Please Enter Your Mobile No");
		        $('#errormsg').html('<p>Please Enter Your Mobile No</p>');
		        return false
		    }

		    alert( "Valid" );
  	});

	$('#btn-submit').click(function () {
		var validateEmail = function(elementValue) {
		    var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
		    return emailPattern.test(elementValue);
		}

		


		var value = $('#email').val();
	    var valid = validateEmail(value);
	    if (!valid) {
	        //alert("Please enter a valid email");        
	        $('#errormsg').html('<p>Please enter a valid email</p>');
	        return false;
	    }

	    $('#email').keyup(function() {

	    	

		    var value = $(this).val();
		    var valid = validateEmail(value);

		    if (!valid) {
		        //$(this).css('color', 'red');
		        $('#errormsg').html('<p>Please Enter eeeeeeee</p>');
		        
		    } else {
		        $(this).css('color', '#000');
		    }

		});

		    alert( "Form Submited" );
  	});










	$('#btn-submit').click(function () {
	  		console.log('am in ');
	  });



// 	$(function(){
//     $('#leadStatusId').change(function(){
//         if($(this).attr('id') == 'box_g1' && $(this).val() == 'Default'){
//             $('#paymentMode').not(this).prop('disabled', true).val('Disabled');
//         } else {
//             $('#paymentMode').not(this).removeProp('disabled');
            
//             $('select option').removeProp('disabled');
//             $('select').each(function(){
//                 var val = $(this).val();
//                 if(val != 'Default' || val != 'Disabled'){
//                     $('select option[value="'+val+'"]').not(this).prop('disabled', true);
//                 }
//             });
//         }
//     });
// });



// select box

            $('select').change(function(){
                    if($(this).attr('id') == 'leadStatusId' && $(this).val() == 'Default'){
                } else {
                    $('select').not(this).removeProp('disabled');
                    $('select').each(function(){
                        var val = $(this).val();
                        if(val != 'Default' || val != 'Disabled'){
                             $('select option[value="'+val+'"]').not(this).prop('disabled', true);
                        }
                    });
                }
            });


});