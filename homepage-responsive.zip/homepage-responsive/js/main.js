$(document).ready(function() {
  
    /*Timeline Carousel*/
    var sync1 = $(".glorious-carousel-image");
    var sync2 = $(".glorious-carousel-year");
    var slidesPerPage = 8; //globaly define number of elements per page
    var syncedSecondary = true;

    sync1.owlCarousel({
        items: 1,
        nav: false,
        dots: false,
        animateIn: 'fadeIn',
        animateOut: 'fadeOut',
    }).on('changed.owl.carousel', syncPosition);

    sync2
        .on('initialized.owl.carousel', function() {
            sync2.find(".owl-item").eq(0).addClass("current");
        })
        .owlCarousel({
            responsiveClass: true,
            responsive: {
                0: {
                    items: 3,
                    touchDrag: true,
                    mouseDrag: true,
                    margin: 80,
                    nav: false,
                    dots: false
                },
                768: {
                    items: 5,
                    margin: 80,
                    touchDrag: true,
                    mouseDrag: true,
                    nav: false,
                    dots: false
                },
                1200: {
                    items: 10,
                    margin: 92,
                    dots: false,
                    nav: false,
                    URLhashListener: true,
                    startPosition: 'URLHash',
                }
            }
        }).on('changed.owl.carousel', syncPosition2);

    function syncPosition(el) {
        var current = el.item.index;
        sync2.find(".owl-item").removeClass("current").eq(current).addClass("current");
        var onscreen = sync2.find('.owl-item.active').length - 1;
        var start = sync2.find('.owl-item.active').first().index();
        var end = sync2.find('.owl-item.active').last().index();
        console.log(start);
        console.log(end);

        if (current > end) {
            sync2.data('owl.carousel').to(current, 100, true);
        }
        if (current < start) {
            sync2.data('owl.carousel').to(current - onscreen, 100, true);
        }
    }

    function syncPosition2(el) {
        if (syncedSecondary) {
            var number = el.item.index;
            sync1.data('owl.carousel').to(number, 100, true);
        }
    }

    sync2.on("click", ".owl-item", function(e) {
        e.preventDefault();
        var number = $(this).index();
        sync1.data('owl.carousel').to(number, 300, true);
    });

    /*Banner Carousel*/
    var one = $(".owl-carousel");
    var banner_carousel = $(".geu-banner-carousel");
    one.owlCarousel({
        items: 4,
        loop: true,
        margin: 5,
        autoplay: true,
        autoplayTimeout: 1000,
        autoplayHoverPause: true
    });

    banner_carousel.owlCarousel({
        items: 1,
        autoplay: true,
        loop: true,
        autoplayTimeout: 2000,
    });

    $('.geu-banner-carousel').addClass('owl-carousel').owlCarousel({
        margin: 10,
        nav: true,
        items: 1,
    });

    /*Counter*/
    $('.count').each(function () {
      $(this).prop('Counter',0).animate({
       Counter: $(this).text()
      }, {
       duration: 4000,
       easing: 'swing',
       step: function (now) {
        $(this).text(Math.ceil(now));
       }
      });
  });
});